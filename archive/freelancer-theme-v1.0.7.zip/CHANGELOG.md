## [1.0.7](https://github.com/johnleider/freelancer/compare/v1.0.5...v1.0.7) (2020-04-26)



## [1.0.5](https://github.com/johnleider/freelancer/compare/300d9ff66927e0d292caad632082fcbfd0993133...v1.0.5) (2020-04-26)


### Bug Fixes

* app-bar and base-btn ([2c5aa5c](https://github.com/johnleider/freelancer/commit/2c5aa5c3538b9dbff29b1a3cdd04a79019037c4a))


### Features

* finish initial implementation ([8d7db33](https://github.com/johnleider/freelancer/commit/8d7db333e85118405f298f6d94af4466bfee0ae6))
* init commit ([300d9ff](https://github.com/johnleider/freelancer/commit/300d9ff66927e0d292caad632082fcbfd0993133))
* tweak styles from review ([b3d929c](https://github.com/johnleider/freelancer/commit/b3d929c5f1aae999bc67207ad4a7e3f5630f0b8a))



